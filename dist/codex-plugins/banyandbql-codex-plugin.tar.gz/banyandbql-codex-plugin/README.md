# BanyanDB QL Codex Plugin Bundle

This bundle contains the BanyanDB QL Codex plugin, its marketplace manifest, the compiled BanyanDB MCP server, and runtime Node dependencies.

## Install

1. Extract this archive.
2. Add the extracted directory as a local Codex plugin marketplace.
3. Install or enable the `banyandbql` plugin from that marketplace.

## Configure

The plugin defaults to `BANYANDB_ADDRESS=localhost:17900`.

For a remote BanyanDB instance, set `BANYANDB_ADDRESS` in the environment used to launch Codex, or edit:

```text
plugins/banyandbql/.mcp.json
```

The bundled MCP server is started by:

```text
plugins/banyandbql/scripts/start-banyandb-mcp.sh
```
